import { config } from 'dotenv';
config();

import '@/ai/flows/currency-conversion.ts';